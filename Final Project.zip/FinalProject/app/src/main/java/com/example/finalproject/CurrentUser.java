package com.example.finalproject;

import java.util.ArrayList;

public class CurrentUser {
    public static String user;
    public static boolean admin;
    public static ArrayList<String> types;
}
